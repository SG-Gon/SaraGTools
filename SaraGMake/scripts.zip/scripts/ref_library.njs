{
  "version": "1.2",
  "dbname": "ref_library",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "ref_library.fasta",
  "number-of-letters": 194273,
  "number-of-sequences": 115,
  "last-updated": "2024-11-18T15:11:00",
  "number-of-volumes": 1,
  "bytes-total": 118132,
  "bytes-to-cache": 50188,
  "files": [
    "ref_library.ndb",
    "ref_library.nhr",
    "ref_library.nin",
    "ref_library.nog",
    "ref_library.nos",
    "ref_library.not",
    "ref_library.nsq",
    "ref_library.ntf",
    "ref_library.nto"
  ]
}
