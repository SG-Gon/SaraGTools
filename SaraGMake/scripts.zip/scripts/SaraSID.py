# Blasts a fasta file against a Reference Sequences Library, parses results, and creates Excel output

from Bio import SearchIO
from Bio import SeqIO
import pandas as pd
import xlsxwriter
from operator import itemgetter
import os
import glob
import subprocess

# USER VARIABLES
input_directory = "results/polished"
output_directory = "results/parsid"
ref_library = "scripts/ref_library"
cutoff_pident = 98
intersp_div = 98

os.makedirs(output_directory, exist_ok=True)

for input_file in glob.glob(os.path.join(input_directory, "*_polished.fasta")):

    print(f"Processing file: {input_file} against reference library")

    blast_output = input_file + ".txt"

    # -------------------------
    # BLAST STEP (FIXED)
    # -------------------------
    blast_cmd = [
        "blastn",
        "-query", input_file,
        "-db", ref_library,
        "-evalue", "0.001",
        "-max_target_seqs", "150",
        "-perc_identity", str(cutoff_pident),
        "-out", blast_output,
        "-outfmt", "6 std qlen slen gaps qcovs"
    ]

    print("Running:", " ".join(blast_cmd))
    subprocess.run(blast_cmd, check=True)

    # -------------------------
    # PARSE BLAST OUTPUT
    # -------------------------
    best_blasts = []

    my_fields = "qseqid sseqid pident length mismatch gapopen qstart qend sstart send evalue bitscore qlen slen gaps qcovs"

    QueryResults = SearchIO.parse(blast_output, "blast-tab", fields=my_fields)

    for QueryResult in QueryResults:
        to_sort = []

        for hit in QueryResult.hits:
            for hsp in hit.hsps:

                qcov = (hsp.query_end - hsp.query_start) / QueryResult.seq_len * 100

                if (qcov >= 75) or (hsp.aln_span > 0.9 * hit.seq_len):
                    to_sort.append(
                        (
                            QueryResult.id,
                            hsp.ident_pct,
                            hit.id,
                            qcov,
                            QueryResult.seq_len,
                            hit.seq_len,
                            hsp.aln_span,
                            hsp.evalue
                        )
                    )

        sorted_hits = sorted(to_sort, reverse=True, key=itemgetter(1))

        if sorted_hits:
            best_blasts.append(sorted_hits[0])

    df = pd.DataFrame(
        best_blasts,
        columns=("query", "%id", "best_match", "%qcov", "qlen", "slen", "aln_len", "evalue")
    )

    print("Parsing completed")

    # -------------------------
    # CHECK TAGS (SAFE LOAD)
    # -------------------------
    path = "./Check_tags.csv"
    check_tags = None

    if os.path.isfile(path):
        check_tags = pd.read_csv(path, sep=None, engine="python")

    df["notes"] = ""

    df_notes = []
    qry_to_check = []

    for qry, pid, sp, qc in zip(df["query"], df["%id"], df["best_match"], df["%qcov"]):

        if (pid < (100 - intersp_div)) or (qc < 75):
            note = "to_check"
            qry_to_check.append(qry)
        else:
            note = ""

            if check_tags is not None:
                for lab, tag in zip(check_tags["Label"], check_tags["Check_tag"]):
                    if lab in sp:
                        note = tag

        df_notes.append(note)

    df["notes"] = df_notes

    # -------------------------
    # FULL BLAST TABLE FOR CHECK
    # -------------------------
    all_blast = pd.read_csv(blast_output, sep="\t", names=my_fields.split())

    df_to_check = pd.DataFrame()

    for check in qry_to_check:
        check_qry = all_blast[all_blast["qseqid"] == check]
        check_qry = check_qry.sort_values(by="pident", ascending=False)
        df_to_check = pd.concat([df_to_check, check_qry], ignore_index=True)

    if not df_to_check.empty:
        df_to_check = df_to_check[
            ["qseqid", "pident", "sseqid", "qcovs", "qlen", "slen", "length", "evalue"]
        ]

    # -------------------------
    # LINEAGE STATS
    # -------------------------
    data_lineage = {}
    keys = []

    with open(ref_library + ".fasta", "r") as fasta:
        for k in SeqIO.parse(fasta, "fasta"):
            keys.append(k.id)

    keys.append(f"Results %id < {cutoff_pident}")

    for key in keys:
        data_lineage[key] = []

    samples = [sam.id for sam in SeqIO.parse(input_file, "fasta")]

    outgroup = [s for s in samples if s not in df["query"].values.tolist()]

    for qr, pi, tax, cov, qln, sln, aln, evl in best_blasts:
        if tax in data_lineage:
            data_lineage[tax].append(qr)

    data_lineage[f"Results %id < {cutoff_pident}"] = outgroup

    df_lineage = pd.DataFrame.from_dict(data_lineage, orient="index").reset_index()
    df_lineage.rename(columns={"index": "Lineages", 0: "Sequences"}, inplace=True)

    n_fasta = len([1 for line in open(input_file) if line.startswith(">")])
    n_taxa = len(data_lineage) - 1

    df_stats = pd.DataFrame({
        "Stats": ["Total taxa RSL", "Total input sequences"],
        "n": [n_taxa, n_fasta]
    })

    # -------------------------
    # EXCEL OUTPUT
    # -------------------------
    excel_output_file = os.path.join(
        output_directory,
        os.path.basename(input_file)
        .replace("_polished", "_blast_results")
        .replace(".fasta", ".xlsx")
    )

    with pd.ExcelWriter(excel_output_file, engine="xlsxwriter") as writer:

        df.to_excel(writer, index=False, sheet_name="Best_blast")
        df_to_check.to_excel(writer, index=False, sheet_name="Results_to_check")
        df_lineage.to_excel(writer, index=False, sheet_name="Lineages")
        df_stats.to_excel(writer, index=False, sheet_name="Summary")

        workbook = writer.book

        format1 = workbook.add_format({"num_format": "0.0"})
        format2 = workbook.add_format({"num_format": "0.00E+00"})

        worksheet1 = writer.sheets["Best_blast"]
        worksheet1.set_column("B:B", None, format1)
        worksheet1.set_column("D:D", None, format1)
        worksheet1.set_column("H:H", None, format2)