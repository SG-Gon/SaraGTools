import os
import pandas as pd

# Step 1: Get the directory path containing Excel files
input_dir = "results/parsid"
output_dir = "results/results_filtered"

# Ensure the output directory exists
os.makedirs(output_dir, exist_ok=True)

# Step 2: Process each Excel file in the input directory
excel_files = [f for f in os.listdir(input_dir) if f.endswith("_blast_results.xlsx")]

if not excel_files:
    print("No Excel (.xlsx) files found in the input directory.")
else:
    print(f"Found {len(excel_files)} Excel files to process.")

    # Step 3: Loop through each Excel file and process it
    for file_name in excel_files:
        input_file = os.path.join(input_dir, file_name)
        
        try:
            # Read the Excel file into a pandas DataFrame
            df = pd.read_excel(input_file)

            # Step 4: Display the first few rows to understand the structure of the data
            print(f"Processing file: {file_name}")
            print("First few rows of the dataset:")
            print(df.head())

            # Step 5: Filter based on identity (ID) > 98 and query coverage (Qcov) > 98
            filtered_df = df[(df['%id'] > 98) & (df['%qcov'] > 98)]

            # Step 6: Save the filtered results to a new Excel file with a new name
            # Remove the '_blast_results' part and append '_filtered_blast_results'
            base_name = os.path.splitext(file_name)[0]  # Get the base name (without extension)
            base_name = base_name.replace('_blast_results', '')  # Remove '_blast_results' if present
            output_file = os.path.join(output_dir, f"{base_name}_filtered_blast_results.xlsx")
            
            filtered_df.to_excel(output_file, index=False)

            print(f"Filtered results saved to: {output_file}")
        
        except Exception as e:
            print(f"Error processing {file_name}: {e}")
    
    print("All files processed.")
