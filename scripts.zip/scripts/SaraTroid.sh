#!/bin/bash

# Get the input FASTQ file and output directory from the arguments
input_file=$1
output_dir=$2

# Ensure the output directory exists
mkdir -p "$output_dir"

# Debugging: Print the input file and output directory
echo "Input file: $input_file"
echo "Output directory: $output_dir"

# Check if the input file exists
if [ ! -f "$input_file" ]; then
    echo "Error: Input file $input_file does not exist!"
    exit 1
fi

# Extract the sample ID from the filename
sample_id=$(basename "$input_file" | sed 's|\.fastq$||')

# Define the output file
output_file="${output_dir}/centroid_${sample_id}.fasta"

# Run vsearch to generate centroids
echo "Processing $input_file -> $output_file"
vsearch --cluster_fast "$input_file" --id 0.98 --centroids "$output_file"

# Check if vsearch completed successfully
if [ $? -eq 0 ]; then
    echo "Successfully processed: $input_file"
else
    echo "Error processing: $input_file"
    exit 1
fi
