#!/bin/bash

# Ensure correct number of arguments
if [ "$#" -ne 2 ]; then
    echo "Usage: $0 <input_path> <output_dir>"
    exit 1
fi

# Get the input path and output directory from arguments
input_path=$1
output_dir=$2

# Create the output directory if it doesn't exist
mkdir -p "$output_dir"

# Loop through each FASTQ file in the input path
for file in ${input_path}/*.fastq; do
    # Extract sample ID from the filename (ensure the pattern matches your filenames)
    sample_id=$(basename "$file" .fastq)

    # Define the output file path
    output_file="${output_dir}/${sample_id}_trimmed.fastq"

    # Debugging output (without offensive language)
    echo "Processing file: $file"
    echo "Output file will be: $output_file"

    # Run NanoFilt with specified parameters
    NanoFilt -q 10 -l 200 --maxlength 350 "$file" > "$output_file"
done


