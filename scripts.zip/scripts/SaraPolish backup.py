import os
import sys
import subprocess

# Check if the correct number of arguments is passed
if len(sys.argv) != 3:
    print("Usage: python SaraPolish.py <input_file> <output_file>")
    sys.exit(1)

# Step 1: Get input and output file paths from arguments
input_file = sys.argv[1].strip()
output_file = sys.argv[2].strip()

# Ensure the output directory exists
output_dir = os.path.dirname(output_file)
os.makedirs(output_dir, exist_ok=True)

# Step 2: Process the input file (individual fasta file, not a directory)
if input_file.endswith(".fasta") and "centroid_" in input_file:
    # No need to list files, we are working directly with the given file
    print(f"Processing {input_file}...")

    # Assuming you want to run minimap2 and racon as part of the polishing process
    # You might need to update this section based on your polishing logic

    # Example: Run some polishing process (e.g., racon)
    overlap_path = input_file.replace(".fasta", ".paf")
    # Running minimap2 to generate overlaps (this is just an example, adjust as needed)
    minimap2_cmd = f"minimap2 -x ava-ont {input_file} {input_file} > {overlap_path}"
    subprocess.run(minimap2_cmd, shell=True, check=True)

    # Example polishing step (replace with your actual polishing logic)
    # Running racon for polishing (you can update this if needed)
    racon_cmd = f"racon {input_file} {overlap_path} {input_file} > {output_file}"
    subprocess.run(racon_cmd, shell=True, check=True)

    print(f"Polishing complete for {input_file}. Output saved to {output_file}")
else:
    print(f"Skipping {input_file} as it does not match the expected format.")
    sys.exit(1)
