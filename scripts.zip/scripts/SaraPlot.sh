#!/bin/bash

# Get the input file, output directory, and sample name from the arguments
input_file=$1
output_dir=$2
sample_name=$3

# Ensure the output directory exists
mkdir -p "$output_dir"

# Run NanoPlot with the correct input file and output directory
NanoPlot --fastq "$input_file" --outdir "$output_dir" --title "$sample_name" --dpi 300 --verbose

# Check if NanoPlot was successful
if [ $? -eq 0 ]; then
    echo "NanoPlot completed for $sample_name"
else
    echo "Error running NanoPlot for $sample_name"
    exit 1
fi

