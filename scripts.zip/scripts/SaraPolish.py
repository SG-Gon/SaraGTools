import os
import subprocess
import sys

# Check if the correct number of arguments is passed
if len(sys.argv) != 3:
    print("Usage: python SaraPolish.py <input_file> <output_file>")
    sys.exit(1)

# Step 1: Get input and output file paths from arguments
input_file = sys.argv[1].strip()
output_file = sys.argv[2].strip()

# Ensure the output directory exists
output_dir = os.path.dirname(output_file)
os.makedirs(output_dir, exist_ok=True)

# Step 2: Check if the input file exists
if not os.path.isfile(input_file):
    print(f"Input file {input_file} does not exist.")
    sys.exit(1)

# Step 3: Directly use subprocess to invoke external commands (minimap2, racon)
# Extract the sample suffix from the filename (without the 'centroid_' part)
sample_suffix = os.path.basename(input_file).split("centroid_")[1].split(".fasta")[0]

# Define the path for the overlap file
overlap_path = os.path.join(output_dir, f"overlap_{sample_suffix}.paf")

# Step 4: Run minimap2 to generate overlaps (you may need to adjust this depending on your setup)
print(f"Running minimap2 for {sample_suffix}...")
minimap2_cmd = f"minimap2 -x ava-ont {input_file} {input_file} > {overlap_path}"
subprocess.run(minimap2_cmd, shell=True, check=True)

# Step 5: Run racon to polish based on overlaps (you may need to adjust this depending on your setup)
print(f"Running racon for {sample_suffix}...")
racon_cmd = f"racon {input_file} {overlap_path} {input_file} > {output_file}"
subprocess.run(racon_cmd, shell=True, check=True)

print(f"Polishing complete for {sample_suffix}. Output saved to {output_file}\n")

print("Polishing process complete.")
